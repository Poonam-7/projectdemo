package com.demoapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.demoapp.dto.TestDto;
import com.demoapp.model.TestModel;
import com.demoapp.service.TestService;

@RestController
public class Test {
	
	@Autowired
	private TestService testService;

	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public String getString()
	{
		return "Hello World";
	}
	
	@RequestMapping(value = "/addEmployee", method = RequestMethod.POST)
	@ResponseBody
	public void addEmployee(@RequestBody TestDto testDto)
	{
		testService.addEmployee(testDto);
	}
	
	@RequestMapping(value = "/getAllEployee", method = RequestMethod.GET)
	@ResponseBody
	public List<TestModel> getAllEmployee(){
		return testService.getAllEmployee();
	}
	
	@RequestMapping(value = "/updateEmployee", method = RequestMethod.PUT)
	@ResponseBody
	public void updateEmployee(@RequestBody TestDto testDto)
	{
		testService.updateEmployee(testDto);
	}
	
	@RequestMapping(value = "/deleteEmployee/{id}", method = RequestMethod.DELETE)
	public List<TestModel> deleteEmployee(@PathVariable int id)
	{
		testService.deleteEmployee(id);
		return testService.getAllEmployee();
	}
}
