package com.demoapp.dao;

import java.util.List;

import com.demoapp.model.TestModel;

public interface TestDao {
	public void addEmployee(TestModel testModel);
	
	public List<TestModel> getAllEmployee();
	
	public void updateEmployee(TestModel testModel);

	public void deleteEmployee(int id);
}
