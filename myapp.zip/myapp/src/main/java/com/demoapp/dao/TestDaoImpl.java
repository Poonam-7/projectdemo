package com.demoapp.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.demoapp.model.TestModel;
@Transactional
@Repository
public class TestDaoImpl implements TestDao{

	@PersistenceContext
	@Autowired
	private EntityManager entityManager;
	
	
	public void addEmployee(TestModel testModel) {
	   try
	   {
		entityManager.persist(testModel);
	   }catch(Exception e)
	   {
		  e.printStackTrace();
	   }
		
}


	public List<TestModel> getAllEmployee() {
		List<TestModel> employeeList=new ArrayList<TestModel>();
		Query testQuery=entityManager.createQuery("select t1.empId, t1.empName from TestModel t1, TestModel t2 where t1.empId=t2.manager");
		employeeList=testQuery.getResultList();
		return employeeList;
	}


	public void updateEmployee(TestModel testModel) {
		 try
		   {
			entityManager.persist(testModel);
		   }catch(Exception e)
		   {
			  e.printStackTrace();
		   }
		
	}


	public void deleteEmployee(int id) {
		TestModel testModel=entityManager.find(TestModel.class, id);
		entityManager.remove(testModel);
	}

}
