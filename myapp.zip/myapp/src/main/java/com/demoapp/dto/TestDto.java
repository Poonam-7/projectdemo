package com.demoapp.dto;

import java.util.HashSet;
import java.util.Set;

import com.demoapp.model.TestModel;

public class TestDto {

	private int id;
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	private String empId;
	
	private String empName;
	
	private TestModel manager;
	
	private Set<TestModel> subordinates = new HashSet<TestModel>();


	public TestModel getManager() {
		return manager;
	}

	public void setManager(TestModel manager) {
		this.manager = manager;
	}

	public Set<TestModel> getSubordinates() {
		return subordinates;
	}

	public void setSubordinates(Set<TestModel> subordinates) {
		this.subordinates = subordinates;
	}
}
