package com.demoapp.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "demoapp")
public class TestModel {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "test_id")
	private int id;
	
	@Column(name = "test_empid")
	private String empId;
	
	@Column(name = "test_empname")
	
	private String empName;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	@ManyToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="test_emp_ref_id")
	private TestModel manager;

	public TestModel getManager() {
		return manager;
	}

	public void setManager(TestModel manager) {
		this.manager = manager;
	}

	public Set<TestModel> getSubordinates() {
		return subordinates;
	}

	public void setSubordinates(Set<TestModel> subordinates) {
		this.subordinates = subordinates;
	}

	@OneToMany(mappedBy="manager")
	private Set<TestModel> subordinates = new HashSet<TestModel>();
}
