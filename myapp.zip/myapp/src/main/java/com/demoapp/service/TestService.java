package com.demoapp.service;

import java.util.List;

import com.demoapp.dto.TestDto;
import com.demoapp.model.TestModel;

public interface TestService {
	public void addEmployee(TestDto testDto);
	public List<TestModel> getAllEmployee();
	public void updateEmployee(TestDto testDto);
	public void deleteEmployee(int id);
}
