package com.demoapp.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demoapp.dao.TestDao;
import com.demoapp.dto.TestDto;
import com.demoapp.model.TestModel;

@Service
public class TestServiceImpl implements TestService{

	@Autowired
	private TestDao testDao;
	
	public void addEmployee(TestDto testDto) {
		TestModel testModel=new TestModel();
		testModel.setEmpId(testDto.getEmpId());
		testModel.setEmpName(testDto.getEmpName());
		testModel.setManager(testDto.getManager());
		
		testDao.addEmployee(testModel);
	}

	public List<TestModel> getAllEmployee() {
		
		return testDao.getAllEmployee();
	}

	public void updateEmployee(TestDto testDto) {
		TestModel testModel=new TestModel();
		testModel.setId(testDto.getId());
		testModel.setEmpId(testDto.getEmpId());
		testModel.setEmpName(testDto.getEmpName());
		testModel.setManager(testDto.getManager());
		
		testDao.updateEmployee(testModel);
	}

	public void deleteEmployee(int id) {
		testDao.deleteEmployee(id);
		
	}

}
